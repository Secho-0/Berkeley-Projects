
local L = LibStub("AceLocale-3.0"):NewLocale("BagSync", "frFR")
if not L then return end

--PLEASE LOOK AT enUS.lua for a complete localization list

--Really wish someone would do the french translation

L.TooltipBag = "Sacs:"
L.TooltipBank = "Banque:"
L.TooltipEquip = "Équipé:"
L.TooltipGuild = "Guilde:"