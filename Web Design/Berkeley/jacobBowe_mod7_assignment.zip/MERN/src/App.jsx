const contentNode = document.getElementById('contents');

const continents = ['Africa','America','Asia','Austrailia','Europe'];
const message = continents.map(c => `Hello ${c}!`).join(';');

const component = <p>{message}</p>; //simple JSX Component
ReactDOM.render(component,contentNode); // Render the component inside the Content Node;